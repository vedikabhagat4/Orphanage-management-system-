package com.anudip.training.exception;

public class AdopterIdNotFoundException extends RuntimeException {
	 public AdopterIdNotFoundException(String message) {
	        super(message);
	    }
}
