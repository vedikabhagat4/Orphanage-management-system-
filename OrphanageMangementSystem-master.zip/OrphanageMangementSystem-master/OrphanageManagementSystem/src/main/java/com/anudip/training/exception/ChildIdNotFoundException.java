package com.anudip.training.exception;

public class ChildIdNotFoundException  extends RuntimeException {
	 public ChildIdNotFoundException(String message) {
	        super(message);
	    }
}