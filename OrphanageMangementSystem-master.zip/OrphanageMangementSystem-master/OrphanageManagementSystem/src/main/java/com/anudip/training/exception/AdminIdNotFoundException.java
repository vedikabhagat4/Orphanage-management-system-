package com.anudip.training.exception;



public class AdminIdNotFoundException extends RuntimeException{

	public AdminIdNotFoundException(String message) {
        super(message);
    }
}
