package com.anudip.training.exception;

public class DonorIdNotFoundException extends RuntimeException {
	 public DonorIdNotFoundException(String message) {
	        super(message);
	    }
}