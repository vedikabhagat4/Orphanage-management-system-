package com.anudip.training.exception;

public class StaffIdNotFoundException extends RuntimeException {
	
	 public StaffIdNotFoundException(String message) {
	        super(message);
	    }
	 
}


