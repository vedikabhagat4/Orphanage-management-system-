package com.anudip.training.exception;

public class OrphanageIdNotFoundException extends RuntimeException {
	
	 public OrphanageIdNotFoundException(String message) {
	        super(message);
	    }
	 
}	 
