package com.anudip.training.service;

import com.anudip.training.entity.Login;

public interface LoginService {

	public Login loginUser(String userNmae,String password);
}
