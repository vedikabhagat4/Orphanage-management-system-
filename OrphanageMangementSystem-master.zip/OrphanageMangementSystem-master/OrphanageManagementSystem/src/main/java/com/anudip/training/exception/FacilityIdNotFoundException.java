package com.anudip.training.exception;

public class FacilityIdNotFoundException extends RuntimeException {
	
	 public FacilityIdNotFoundException(String message) {
	        super(message);
	    }
}
	 
